videoPath = '/home/gentoowork/Desktop/motionDetectionData/PTZ/intermittentPan';
binaryFolder = '/home/gentoowork/Desktop/motionDetectionData/PTZ/intermittentPan/mcdMask';


cm = processVideoFolder(videoPath,binaryFolder);

[TP FP FN TN SE stats] = confusionMatrixToVar(cm,binaryFolder)